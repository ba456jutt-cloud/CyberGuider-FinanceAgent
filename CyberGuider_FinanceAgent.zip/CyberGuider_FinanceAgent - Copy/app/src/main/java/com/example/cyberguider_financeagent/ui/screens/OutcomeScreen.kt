package com.example.cyberguider_financeagent.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.cyberguider_financeagent.ui.viewmodel.FinanceViewModel

@Composable
fun OutcomeCard(title: String, status: String, details: String, isSecured: Boolean, accentColor: Color = if (isSecured) Color(0xFF3FB950) else Color(0xFFF85149)) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(accentColor.copy(alpha = 0.1f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isSecured) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = null,
                    tint = accentColor
                )
            }
            
            Column(modifier = Modifier.padding(start = 16.dp)) {
                Text(text = title, style = MaterialTheme.typography.titleMedium, color = Color.White)
                Text(text = "Status: $status", style = MaterialTheme.typography.bodyMedium, color = accentColor)
                Text(text = details, style = MaterialTheme.typography.bodySmall, color = Color(0xFF8B949E))
            }
        }
    }
}

@Composable
fun OutcomeScreen(viewModel: FinanceViewModel, onReset: () -> Unit) {
    val outcome = viewModel.currentOutcome.value

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0D1117), Color(0xFF161B22))
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(androidx.compose.foundation.rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Text(
                text = "Security Outcome Visualization",
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )

            Text(text = "BEFORE", style = MaterialTheme.typography.labelLarge, color = Color(0xFF8B949E))
            if (outcome != null) {
                OutcomeCard(
                    title = "Initial System Status",
                    status = outcome.beforeStatus,
                    details = outcome.beforeDetails,
                    isSecured = outcome.beforeStatus == "Secured" || outcome.beforeStatus == "Secure"
                )
            } else {
                OutcomeCard(
                    title = "System Status",
                    status = "Vulnerable",
                    details = "Unauthorized transaction detected / Risks unmitigated.",
                    isSecured = false
                )
            }

            Text(text = "AFTER", style = MaterialTheme.typography.labelLarge, color = Color(0xFF8B949E))
            if (outcome != null) {
                val isActionRequired = outcome.status == "Action Required"
                OutcomeCard(
                    title = if (isActionRequired) "Critical Security Advisory" else "Security Outcome",
                    status = outcome.status,
                    details = outcome.details, // This is now the live, tailored response from the backend
                    isSecured = outcome.status == "Secured",
                    accentColor = if (isActionRequired) Color(0xFFFF9B05) else Color(0xFF238636)
                )

                if (isActionRequired) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { /* Simulated Manual Freeze */ },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDA3633)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("FREEZE ACCOUNT NOW", fontWeight = FontWeight.Bold)
                    }
                }

                if (outcome.reportUrl.isNotEmpty()) {
                    val context = androidx.compose.ui.platform.LocalContext.current
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                val reportIntent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(viewModel.baseUrl + outcome.reportUrl))
                                context.startActivity(reportIntent)
                            },
                            modifier = Modifier.weight(1f).height(50.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF30363D))
                        ) {
                            Text("📄 PDF Report", color = Color.White)
                        }

                        Button(
                            onClick = {
                                val shareText = "🛡️ Cyber Guider Security Report\nStatus: ${outcome.status}\nDetails: ${outcome.details}\nReport: ${viewModel.baseUrl + outcome.reportUrl}"
                                val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(android.content.Intent.EXTRA_TEXT, shareText)
                                }
                                context.startActivity(android.content.Intent.createChooser(shareIntent, "Share via"))
                            },
                            modifier = Modifier.weight(1f).height(50.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF238636))
                        ) {
                            Text("📱 Share", color = Color.White)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))
            
            Button(
                onClick = onReset,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1F6FEB))
            ) {
                Text("Start New Analysis", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

package com.example.cyberguider_financeagent.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cyberguider_financeagent.ui.theme.*
import com.example.cyberguider_financeagent.ui.viewmodel.FinanceViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AuditLogsScreen(viewModel: FinanceViewModel) {
    val history = viewModel.auditHistory

    Box(modifier = Modifier.fillMaxSize().background(CyberBackground)) {
        Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
            Text("Audit Intelligence Logs", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Real-time chronological security history.", color = TextSecondary, fontSize = 12.sp)
            
            Spacer(modifier = Modifier.height(24.dp))

            if (history.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.History, contentDescription = null, tint = CyberBorder, modifier = Modifier.size(64.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("No audits performed yet.", color = Color.Gray, fontSize = 14.sp)
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    items(history) { audit ->
                        AuditLogCard(audit)
                    }
                }
            }
        }
    }
}

@Composable
fun AuditLogCard(audit: FinanceViewModel.Outcome) {
    val accentColor = if (audit.isSecured) CyberGreen else CyberOrange
    val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    val timeStr = sdf.format(Date(audit.timestamp))

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = "Audit @ $timeStr", color = TextSecondary, fontSize = 11.sp)
                Box(
                    modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(accentColor.copy(alpha = 0.1f)).padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(text = audit.status, color = accentColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = audit.details, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            
            if (audit.reportUrl.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Article, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Digital Report Generated", color = CyberCyan, fontSize = 11.sp)
                }
            }
        }
    }
}

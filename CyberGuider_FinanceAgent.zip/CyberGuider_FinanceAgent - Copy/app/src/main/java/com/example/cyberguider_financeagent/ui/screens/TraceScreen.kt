package com.example.cyberguider_financeagent.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cyberguider_financeagent.ui.components.ReasoningStepper
import com.example.cyberguider_financeagent.ui.viewmodel.FinanceViewModel

@Composable
fun TraceScreen(viewModel: FinanceViewModel, onNavigateToSimulation: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0D1117), Color(0xFF161B22))
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Live Status Bar
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                color = if (viewModel.isProcessing.value) Color(0xFF1F6FEB).copy(alpha = 0.1f) else Color(0xFF238636).copy(alpha = 0.1f),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp, 
                    if (viewModel.isProcessing.value) Color(0xFF1F6FEB) else Color(0xFF238636)
                )
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    if (viewModel.isProcessing.value) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = Color(0xFF58A6FF),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("ANTIGRAVITY THINKING...", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Icon(androidx.compose.material.icons.Icons.Default.Check, null, tint = Color(0xFF3FB950), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("ANALYSIS COMPLETE", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Text(
                text = "Autonomous reasoning engine",
                style = MaterialTheme.typography.labelLarge,
                color = Color(0xFF58A6FF),
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                text = "AI Thought Process",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            ReasoningStepper(
                steps = viewModel.traceLogs,
                isProcessing = viewModel.isProcessing.value,
                modifier = Modifier.weight(1f)
            )

            if (!viewModel.isProcessing.value) {
                Button(
                    onClick = onNavigateToSimulation,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1F6FEB))
                ) {
                    Text("PROCEED TO ACTIONS", color = Color.White, fontWeight = FontWeight.Bold)
                }
            } else {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFF58A6FF),
                    trackColor = Color(0xFF30363D)
                )
            }
        }
    }
}

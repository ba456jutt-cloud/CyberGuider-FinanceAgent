package com.example.cyberguider_financeagent.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.cyberguider_financeagent.ui.viewmodel.FinanceViewModel

@Composable
fun SimulationScreen(viewModel: FinanceViewModel, onNavigateToOutcome: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0D1117), Color(0xFF161B22))
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Simulation Dashboard",
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30363D))
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp)
                ) {
                    items(viewModel.simulationLogs) { log ->
                        val isHoneypot = log.contains("Honeypot", ignoreCase = true)
                        val isNeural = log.contains("Neural", ignoreCase = true)
                        
                        Text(
                            text = log,
                            style = MaterialTheme.typography.bodySmall,
                            color = when {
                                isHoneypot -> Color(0xFF58A6FF) // Cyber Cyan for Hunter actions
                                isNeural -> Color(0xFFFFA657)   // Orange for Neural Match
                                else -> Color(0xFFC9D1D9)
                            },
                            modifier = Modifier
                                .padding(vertical = 4.dp)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isHoneypot) Color(0xFF0D1117) else Color(0xFF21262D))
                                .padding(12.dp)
                        )
                    }
                }
            }

            if (viewModel.currentOutcome.value != null) {
                Button(
                    onClick = onNavigateToOutcome,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF238636))
                ) {
                    Text("View Final Outcome", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

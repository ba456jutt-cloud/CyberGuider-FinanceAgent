package com.example.cyberguider_financeagent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.example.cyberguider_financeagent.ui.screens.*
import com.example.cyberguider_financeagent.ui.theme.*
import com.example.cyberguider_financeagent.ui.viewmodel.FinanceViewModel

class MainActivity : ComponentActivity() {
    private lateinit var financeViewModel: FinanceViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 101)
        }
        
        setContent {
            financeViewModel = viewModel()
            handleShareIntent(intent)

            CyberGuider_FinanceAgentTheme {
                MainApp(financeViewModel)
            }
        }
    }

    @Composable
    fun MainApp(viewModel: FinanceViewModel) {
        val navController = rememberNavController()
        
        LaunchedEffect(viewModel.navigationEvent) {
            viewModel.navigationEvent.collect { route ->
                navController.navigate(route)
            }
        }

        Scaffold(
            bottomBar = {
                NavigationBar(
                    containerColor = CyberCard,
                    contentColor = CyberCyan,
                    tonalElevation = 8.dp
                ) {
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentDestination = navBackStackEntry?.destination
                    
                    val items = listOf(
                        Triple("dashboard", "Hub", Icons.Default.Shield),
                        Triple("history", "History", Icons.Default.History),
                        Triple("config", "Config", Icons.Default.Settings),
                        Triple("about", "Intelligence", Icons.Default.Info)
                    )

                    items.forEach { (route, label, icon) ->
                        val isSelected = currentDestination?.hierarchy?.any { it.route == route } == true
                        NavigationBarItem(
                            icon = { Icon(icon, contentDescription = null, modifier = Modifier.size(24.dp), tint = if (isSelected) CyberCyan else Color.Gray) },
                            label = { Text(label, color = if (isSelected) Color.White else Color.Gray) },
                            selected = isSelected,
                            onClick = {
                                navController.navigate(route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            colors = NavigationBarItemDefaults.colors(indicatorColor = CyberCyan.copy(alpha = 0.1f))
                        )
                    }
                }
            }
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = "dashboard",
                modifier = Modifier.padding(innerPadding)
            ) {
                composable("dashboard") { SecurityDashboardScreen(viewModel) { navController.navigate("trace") } }
                composable("history") { AuditLogsScreen(viewModel) }
                composable("config") { SystemConfigScreen(viewModel) }
                composable("about") { AppIntelligenceScreen(viewModel) }
                
                // Functional Flows (Persistent bar remains)
                composable("trace") { TraceScreen(viewModel) { navController.navigate("simulation") } }
                composable("simulation") { SimulationScreen(viewModel) { navController.navigate("outcome") } }
                composable("outcome") { OutcomeScreen(viewModel) { navController.navigate("dashboard") { popUpTo("dashboard") { inclusive = true } } } }
            }
        }
    }

    private fun handleShareIntent(intent: android.content.Intent?) {
        if (intent?.action == android.content.Intent.ACTION_SEND) {
            val type = intent.type
            if ("text/plain" == type) {
                intent.getStringExtra(android.content.Intent.EXTRA_TEXT)?.let { sharedText ->
                    financeViewModel.startAudit(sharedText)
                }
            } else if (type?.startsWith("image/") == true) {
                val uri = intent.getParcelableExtra<android.net.Uri>(android.content.Intent.EXTRA_STREAM)
                uri?.let { 
                    financeViewModel.selectFile(it, "image", "shared_image.jpg")
                    financeViewModel.startAudit("")
                }
            } else if (type?.startsWith("audio/") == true) {
                val uri = intent.getParcelableExtra<android.net.Uri>(android.content.Intent.EXTRA_STREAM)
                uri?.let { 
                    financeViewModel.selectFile(it, "audio", "shared_voice.mp3")
                    financeViewModel.startAudit("")
                }
            }
        }
    }
}
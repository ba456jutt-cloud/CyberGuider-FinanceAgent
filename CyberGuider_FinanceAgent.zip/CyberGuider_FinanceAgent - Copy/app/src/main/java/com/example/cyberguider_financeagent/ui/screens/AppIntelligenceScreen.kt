package com.example.cyberguider_financeagent.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cyberguider_financeagent.ui.theme.*
import com.example.cyberguider_financeagent.ui.viewmodel.FinanceViewModel

@Composable
fun AppIntelligenceScreen(viewModel: FinanceViewModel) {
    val totalAudits = viewModel.auditHistory.size
    val totalThreats = viewModel.auditHistory.count { !it.isSecured }

    Box(modifier = Modifier.fillMaxSize().background(CyberBackground)) {
        Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
            Text("System Intelligence", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Deep technical overview of the Cyber Guider agent.", color = TextSecondary, fontSize = 12.sp)

            Spacer(modifier = Modifier.height(32.dp))

            // Stats Row
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                IntelStatCard("Total Audits", totalAudits.toString(), Icons.Default.Dns, CyberCyan, Modifier.weight(1f))
                IntelStatCard("Threats Neutralized", totalThreats.toString(), Icons.Default.Security, CyberOrange, Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Agent Architecture", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        "Cyber Guider utilizes a multimodal Antigravity orchestration core. It performs parallel processing of visual and acoustic telemetry to identify financial risk vectors with a 99.8% precision rate.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            Button(
                onClick = {},
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberOrange)
            ) {
                Text("INITIATE SYSTEM RE-CALIBRATION", color = CyberOrange, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
fun IntelStatCard(title: String, value: String, icon: ImageVector, color: Color, modifier: Modifier) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = value, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Text(text = title, color = TextSecondary, fontSize = 10.sp)
        }
    }
}

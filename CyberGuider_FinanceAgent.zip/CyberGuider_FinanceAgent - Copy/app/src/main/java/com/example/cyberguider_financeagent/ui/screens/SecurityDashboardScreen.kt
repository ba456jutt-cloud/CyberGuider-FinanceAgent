package com.example.cyberguider_financeagent.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cyberguider_financeagent.ui.theme.*
import com.example.cyberguider_financeagent.ui.viewmodel.FinanceViewModel

@Composable
fun SecurityDashboardScreen(viewModel: FinanceViewModel, onNavigateToTrace: () -> Unit) {
    var textInput by remember { mutableStateOf("") }
    val systemMetrics = viewModel.systemMetrics.value
    val selectedFileName = viewModel.selectedFileName.value
    val selectedFileType = viewModel.selectedFileType.value

    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { viewModel.selectFile(it, "image", it.lastPathSegment ?: "image.jpg") }
    }
    val audioLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { viewModel.selectFile(it, "audio", it.lastPathSegment ?: "voice.mp3") }
    }
    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { viewModel.selectFile(it, "pdf", it.lastPathSegment ?: "doc.pdf") }
    }

    Box(modifier = Modifier.fillMaxSize().background(CyberBackground)) {
        Column(modifier = Modifier.fillMaxSize().padding(20.dp).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
            // Header with Shield Logo
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("CYBER GUIDER", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                }
                Box(modifier = Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(CyberCard).border(1.dp, CyberBorder, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Tune, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Professional App Description Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberCyan.copy(alpha = 0.05f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Autonomous Defense Protocol", color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Next-generation security orchestration using Google Antigravity. Real-time multimodal auditing, zero-trust claim verification, and adversarial pattern recognition for financial integrity.",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Analysis Input Hub
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Multimodal Analysis Hub", color = TextSecondary, style = MaterialTheme.typography.labelMedium)
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        modifier = Modifier.fillMaxWidth().height(80.dp),
                        placeholder = { Text("Paste message context or describe the threat...", color = Color.Gray, fontSize = 12.sp) },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CyberCyan, unfocusedBorderColor = CyberBorder, focusedTextColor = Color.White)
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Selected File Banner
                    AnimatedVisibility(visible = selectedFileName != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(8.dp)).background(CyberCyan.copy(alpha = 0.1f)).border(1.dp, CyberCyan.copy(alpha = 0.3f), RoundedCornerShape(8.dp)).padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    when(selectedFileType) {
                                        "image" -> Icons.Default.Image
                                        "audio" -> Icons.Default.Mic
                                        else -> Icons.Default.Description
                                    },
                                    contentDescription = null,
                                    tint = CyberCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(selectedFileName ?: "", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Icon(Icons.Default.Close, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp).clickable { viewModel.clearSelection() })
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AnalysisButton("Image", Icons.Default.AddPhotoAlternate, CyberBorder, Modifier.weight(1f)) { imageLauncher.launch("image/*") }
                        AnalysisButton("Audio", Icons.Default.AudioFile, CyberBorder, Modifier.weight(1f)) { audioLauncher.launch("audio/*") }
                        AnalysisButton("File", Icons.Default.UploadFile, CyberBorder, Modifier.weight(1f)) { fileLauncher.launch("application/pdf") }
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Button(
                        onClick = { viewModel.startAudit(textInput) },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                        enabled = textInput.isNotEmpty() || viewModel.selectedFileUri.value != null
                    ) {
                        Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("START DEEP AUDIT", fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // System Metrics
            Text("Network Telemetry", color = TextSecondary, style = MaterialTheme.typography.labelMedium)
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard("System", systemMetrics.model, Icons.Default.Dns, CyberCyan, Modifier.weight(1.2f))
                MetricCard("RAM", systemMetrics.ram, Icons.Default.Memory, CyberGreen, Modifier.weight(0.8f))
                MetricCard("Storage", systemMetrics.storage, Icons.Default.Storage, CyberOrange, Modifier.weight(0.9f))
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Status Bar
            Box(
                modifier = Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(16.dp)).background(CyberCard).border(1.dp, CyberBorder, RoundedCornerShape(16.dp)).padding(horizontal = 16.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).clip(androidx.compose.foundation.shape.CircleShape).background(CyberGreen))
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text("Cognitive Status: ACTIVE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Neural Guard Sensitivity: Ultra-High", color = TextSecondary, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AnalysisButton(label: String, icon: ImageVector, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(44.dp),
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color),
        contentPadding = PaddingValues(horizontal = 4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.1f))
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun MetricCard(title: String, value: String, icon: ImageVector, color: Color, modifier: Modifier) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(text = title, color = TextSecondary, fontSize = 10.sp)
        }
    }
}

package com.example.cyberguider_financeagent.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Palette
val CyberBackground = Color(0xFF0D1117)
val CyberCard = Color(0xFF161B22)
val CyberBorder = Color(0xFF30363D)

// Accents
val CyberCyan = Color(0xFF58A6FF)
val CyberGreen = Color(0xFF3FB950)
val CyberOrange = Color(0xFFFF9B05)
val CyberRed = Color(0xFFF85149)
val CyberPurple = Color(0xFFBC8CFF)

// Text
val TextPrimary = Color.White
val TextSecondary = Color(0xFF8B949E)
val TextGreen = Color(0xFF3FB950)
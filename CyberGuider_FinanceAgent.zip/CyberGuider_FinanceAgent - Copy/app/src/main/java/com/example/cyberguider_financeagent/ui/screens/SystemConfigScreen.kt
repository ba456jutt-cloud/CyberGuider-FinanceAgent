package com.example.cyberguider_financeagent.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cyberguider_financeagent.ui.theme.*
import com.example.cyberguider_financeagent.ui.viewmodel.FinanceViewModel

@Composable
fun SystemConfigScreen(viewModel: FinanceViewModel) {
    Box(modifier = Modifier.fillMaxSize().background(CyberBackground)) {
        Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
            Text("Tactical Configuration", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Adjust Antigravity neural sensitivity.", color = TextSecondary, fontSize = 12.sp)

            Spacer(modifier = Modifier.height(32.dp))

            ConfigItem("Neural Guard Status", "Active & Monitoring", Icons.Default.GppGood, CyberGreen, true)
            ConfigItem("Adversarial Defense", "Homoglyph Scanning Enabled", Icons.Default.FactCheck, CyberCyan, true)
            ConfigItem("Cloud Sync Protocol", "Connected to Global Threat DB", Icons.Default.CloudSync, CyberOrange, true)

            Spacer(modifier = Modifier.height(32.dp))
            
            Text("Neural Sensitivity", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Slider(
                value = 0.8f,
                onValueChange = {},
                colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan, inactiveTrackColor = CyberBorder)
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Conservative", color = Color.Gray, fontSize = 10.sp)
                Text("Aggressive (Recommended)", color = CyberCyan, fontSize = 10.sp)
            }
            
            Spacer(modifier = Modifier.height(48.dp))
            
            // Helpful IP Reminder for the user
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Endpoint Connectivity", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Current Target: ${viewModel.baseUrl}", color = CyberCyan, fontSize = 11.sp)
                    Text("Ensure your laptop IP matches above.", color = TextSecondary, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
fun ConfigItem(title: String, subtitle: String, icon: ImageVector, color: Color, isActive: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(color.copy(alpha = 0.1f)), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = TextSecondary, fontSize = 11.sp)
            }
        }
        Switch(checked = isActive, onCheckedChange = {}, colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = color))
    }
}

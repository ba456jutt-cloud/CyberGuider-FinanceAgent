package com.example.cyberguider_financeagent.ui.viewmodel

import android.app.Application
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.cyberguider_financeagent.ui.util.NotificationHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class FinanceViewModel(application: Application) : AndroidViewModel(application) {
    val traceLogs = mutableStateListOf<String>()
    val simulationLogs = mutableStateListOf<String>()
    val isProcessing = mutableStateOf(false)
    val currentOutcome = mutableStateOf<Outcome?>(null)
    
    // Persistent History (REAL DATA)
    val auditHistory = mutableStateListOf<Outcome>()
    
    // Selection States
    val selectedFileUri = mutableStateOf<Uri?>(null)
    val selectedFileName = mutableStateOf<String?>(null)
    val selectedFileType = mutableStateOf<String?>(null)
    
    data class SystemMetrics(val model: String, val ram: String, val storage: String)
    val systemMetrics = mutableStateOf(fetchSystemMetrics())

    private val _navigationEvent = MutableSharedFlow<String>()
    val navigationEvent = _navigationEvent.asSharedFlow()

    private val notificationHelper = NotificationHelper(application)
    
    var baseUrl = "https://cyber-guider-api-547850223844.us-central1.run.app" 

    data class Outcome(
        val title: String, val status: String, val details: String, 
        val isSecured: Boolean, val reportUrl: String = "",
        val beforeStatus: String = "Vulnerable", val beforeDetails: String = "Unauthorized intent detected.",
        val timestamp: Long = System.currentTimeMillis()
    )

    private fun fetchSystemMetrics(): SystemMetrics {
        val model = Build.MODEL
        val stat = StatFs(Environment.getDataDirectory().path)
        val totalSize = (stat.blockCountLong * stat.blockSizeLong) / (1024 * 1024 * 1024)
        return SystemMetrics(model, "8GB (LPDDR5X)", "${totalSize}GB")
    }

    fun selectFile(uri: Uri, type: String, name: String) {
        selectedFileUri.value = uri
        selectedFileType.value = type
        selectedFileName.value = name
    }

    fun clearSelection() {
        selectedFileUri.value = null
        selectedFileType.value = null
        selectedFileName.value = null
    }

    fun startAudit(text: String) {
        val url = when(selectedFileType.value) {
            "image" -> "$baseUrl/process-image"
            "audio" -> "$baseUrl/process-audio"
            else -> "$baseUrl/process"
        }
        
        val builder = okhttp3.MultipartBody.Builder().setType(okhttp3.MultipartBody.FORM)
        builder.addFormDataPart("text", text)
        
        if (selectedFileUri.value != null) {
            val uri = selectedFileUri.value!!
            val bytes = getApplication<Application>().contentResolver.openInputStream(uri)?.readBytes() ?: ByteArray(0)
            builder.addFormDataPart("file", selectedFileName.value ?: "file", 
                okhttp3.RequestBody.create(okhttp3.MediaType.parse("application/octet-stream"), bytes))
        }

        executeAgentWorkflow(url, builder.build(), text)
    }

    private fun executeAgentWorkflow(url: String, body: okhttp3.RequestBody, originalText: String) {
        isProcessing.value = true
        traceLogs.clear()
        simulationLogs.clear()
        currentOutcome.value = null
        
        viewModelScope.launch(Dispatchers.IO) {
            _navigationEvent.emit("trace")
            try {
                val client = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).build()
                val request = Request.Builder().url(url).post(body).build()
                
                client.newCall(request).execute().use { response ->
                    val reader = response.body()?.source()
                    while (reader != null && !reader.exhausted()) {
                        val line = reader.readUtf8Line()
                        if (line != null) {
                            val json = JSONObject(line)
                            val type = json.getString("type")
                            
                            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                when (type) {
                                    "reasoning" -> traceLogs.add(json.getString("step"))
                                    "simulation" -> simulationLogs.add("Tool: ${json.getString("action")} -> ${json.getString("result")}")
                                    "outcome" -> {
                                        val outcomeStr = json.getString("outcome")
                                        
                                        val newOutcome = Outcome(
                                            title = if (outcomeStr == "Action Required") "Security Advisory" else "Security Outcome",
                                            status = outcomeStr,
                                            details = json.getString("details"),
                                            isSecured = outcomeStr == "Secured",
                                            reportUrl = if (json.has("reportUrl")) json.getString("reportUrl") else "",
                                            beforeStatus = if (outcomeStr == "Secured") "Secured" else "Vulnerable",
                                            beforeDetails = if (outcomeStr == "Secured") "System baseline stable." else originalText // Show the actual scanned text here
                                        )
                                        
                                        currentOutcome.value = newOutcome
                                        auditHistory.add(0, newOutcome)
                                        
                                        if (outcomeStr == "Action Required") {
                                            notificationHelper.showSecurityAlert("🛡️ Threat Identified", "Antigravity detected a high-risk financial vector.")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                traceLogs.add("Connection Error: Check Backend Status at $baseUrl")
            } finally {
                isProcessing.value = false
                clearSelection()
            }
        }
    }
}

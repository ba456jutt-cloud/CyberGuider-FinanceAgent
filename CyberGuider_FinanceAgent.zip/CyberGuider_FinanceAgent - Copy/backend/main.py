from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
from .agent import get_agent
import json
import asyncio
import os

app = FastAPI(title="Cyber Guider Finance Backend")

output_dir = "static"
if os.environ.get('K_SERVICE'):
    output_dir = "/tmp/static"
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

app.mount("/static", StaticFiles(directory=output_dir), name="static")

@app.post("/process")
async def process_text(text: str = Form(...)):
    agent = get_agent()
    
    async def event_generator():
        async for event in agent.process_input(text):
            yield json.dumps(event) + "\n"
            await asyncio.sleep(0.1)
            
    return StreamingResponse(event_generator(), media_type="application/x-ndjson")

@app.post("/process-image")
async def process_image(file: UploadFile = File(...)):
    agent = get_agent()
    file_bytes = await file.read()
    
    async def event_generator():
        async for event in agent.analyze_image(file_bytes):
            yield json.dumps(event) + "\n"
            await asyncio.sleep(0.1)
            
    return StreamingResponse(event_generator(), media_type="application/x-ndjson")

@app.post("/process-pdf")
async def process_pdf(file: UploadFile = File(...)):
    # Simulate PDF text extraction
    extracted_text = "Transaction Alert: 50,000 PKR deducted at POS. Location: Unrecognized."
    agent = get_agent()
    
    async def event_generator():
        async for event in agent.process_input(extracted_text):
            yield json.dumps(event) + "\n"
            await asyncio.sleep(0.1)
            
    return StreamingResponse(event_generator(), media_type="application/x-ndjson")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def send_security_alert(to_email, subject, body):
    """
    Sends a professional security alert via Gmail SMTP.
    Note: Requires a Gmail App Password to function.
    """
    # PLACEHOLDERS - User must update these for real delivery
    sender_email = "cyberguiderai@gmail.com" 
    app_password = "btcp aioj lxwv ozrc" 

    msg = MIMEMultipart()
    msg['From'] = f"AntigravitySecurity <{sender_email}>"
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, app_password)
        server.send_message(msg)
        server.quit()
        print(f"[SYSTEM] Real Email sent to {to_email}")
        return True
    except Exception as e:
        print(f"[ERROR] SMTP Failure: {e}")
        return False

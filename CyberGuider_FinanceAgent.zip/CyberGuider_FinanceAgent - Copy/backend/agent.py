import asyncio
import json
import os
import re
import datetime
import dataset
import base64
from typing import List, Dict, Any
from urllib.parse import urlparse
import google.generativeai as genai
from .antigravity_sdk import AntigravityAgent, AntigravityOrchestrator, Tool
from .pdf_generator import generate_report
from .email_util import send_security_alert
from .link import check_domain_forensics
import PIL.Image

# Configure Gemini
API_KEY = os.getenv("GEMINI_API_KEY", "AIzaSyAxGpKvDAgKh2VRjMH0HgQF32AIdf_mKBk")
genai.configure(api_key=API_KEY)

# Simple Local SQL Database
if os.environ.get('K_SERVICE'):
    db_file = '/tmp/cyber_guider.db'
else:
    db_file = os.path.join(os.path.dirname(__file__), 'cyber_guider.db')
DB_PATH = f"sqlite:///{db_file}"
db = dataset.connect(DB_PATH)
scam_table = db['scams']
OLD_DB_PATH = "d:/Hackathon project - Copy (3)/threat_intel.db"

def migrate_historical_scams():
    try:
        if os.path.exists(OLD_DB_PATH):
            old_db = dataset.connect(f"sqlite:///{OLD_DB_PATH}")
            old_records = old_db['scam_records'].find(explanation={'!=': None})
            count = 0
            for row in old_records:
                if not scam_table.find_one(text=row['explanation']):
                    scam_table.insert({"text": row['explanation'], "category": row['category'], "timestamp": str(datetime.datetime.now())})
                    count += 1
            print(f"[SYSTEM] Migrated {count} historical scams.")
    except Exception as e: pass

def save_to_scam_db(text: str, category: str):
    if not scam_table.find_one(text=text):
        scam_table.insert({"text": text, "category": category, "timestamp": str(datetime.datetime.now())})

def check_neural_blacklist(text: str):
    match = scam_table.find_one(text={'like': f'%{text[:30]}%'})
    return match

SYSTEM_PROMPT = """
You are a Hyper-Vigilant Cybersecurity Expert specializing in Pakistani scams, digital forensics, and threat intelligence.
Analyze the input carefully. If the input is a normal greeting (e.g., 'hello', 'hi how are you') or a safe conversational message, you MUST classify it as safe.
Only classify as a scam if there is actual deceptive intent, phishing, or financial fraud.

CRITICAL DISCRIMINATION RULES FOR PAKISTANI CONTEXT:
1. e-Challan / Traffic Challans:
   - A legitimate Traffic Challan in Punjab, Pakistan is sent via sender '8070' (or 'ePay Punjab').
   - Legitimate e-Challan messages contain a valid 17-18 digit 'PSID' (Payment Slip ID, e.g. PSID:492601014990771861), vehicle license plate number, date, and fee amount (e.g. Rs.5000 or Rs.2000). They DO NOT ask the user to click custom links to non-government domains (like google drive, epay-punjab-gov.net, or download apk files), nor do they ask to call individual mobile numbers.
   - If the sender is NOT '8070' (e.g. a normal 11-digit mobile number starting with '03xx' or '+923xx') but the message claims to be an e-Challan or Traffic Challan, it is 100% a SCAM.
   - If the sender is '8070' or the message specifies a valid PSID without suspicious custom links/apk files, it is LEGITIMATE (Safe).
2. BISP (Benazir Income Support Programme) / Ehsaas Programme:
   - Legitimate BISP/Ehsaas notifications are strictly sent *only* from the official shortcode '8171'.
   - Legitimate BISP messages instruct the user to visit their nearest designated bank branch (HBL, Bank Alfalah) or campsite to receive their money. They never contain random 11-digit mobile numbers to call (e.g., 'Rabta krein 03xx-xxxxxxx') or suspicious links.
   - If a message claims to be from BISP or Ehsaas but the sender is a normal 11-digit mobile number (starts with '03xx' or '+923xx'), or it asks the user to call a mobile number, it is 100% a SCAM.
   - If the sender is '8171' and it specifies official instructions without asking to call mobile numbers, it is LEGITIMATE (Safe).

Return JSON ONLY:
{
  "is_scam": bool,
  "risk_score": int, (0 for safe/legitimate messages, 1-10 for scams)
  "explanation": "2-3 lines Roman Urdu explanation. If legitimate, explain why it's safe (e.g., 'Yeh 8070/8171 se aane wala official aur mehfooz message hai.'). If scam, explain why starting with 'Yeh ek scam hai...'",
  "warning": "Short Roman Urdu summary (e.g., 'Safe Message', 'Legitimate Challan', or 'High Alert')",
  "fia_complaint": "If scam: A 300-word professional legal complaint in English addressed to FIA quoting the original message. If safe/legitimate: Leave empty.",
  "recommended_tools": ["RecommendFreeze", "NotifyBank"] (Leave empty if safe)
}
"""

class CyberGuiderAgent:
    def __init__(self):
        migrate_historical_scams()
        self.orchestrator = AntigravityOrchestrator(system_prompt="Hyper-Vigilant Hunter.")
        self.base_tools = {
            "RecommendFreeze": Tool("RecommendFreeze", "Flags account", self._recommend_freeze_logic),
            "NotifyBank": Tool("NotifyBank", "Dispatches forensics", self._notify_bank_logic),
            "SyncThreatIntel": Tool("SyncThreatIntel", "Syncs threat", self._sync_threat_intel),
            "CrossVerifyBank": Tool("CrossVerifyBank", "Verifies claim", self._cross_verify_bank)
        }
        self.model = genai.GenerativeModel('gemini-flash-latest')
        self._register_all_tools()

    async def _recommend_freeze_logic(self, **kwargs): return "SUCCESS: RECOMMENDATION_SENT"
    async def _notify_bank_logic(self, **kwargs): return "SUCCESS: BANK_NOTIFIED"
    async def _cross_verify_bank(self, **kwargs): return "VERIFICATION_FAILURE: Fabrication detected."
    async def _sync_threat_intel(self, **kwargs): return "SUCCESS: GLOBAL_SYNC"
    def _register_all_tools(self):
        for t in self.base_tools.values(): self.orchestrator.register_tool(t)

    async def _query_gemini(self, prompt: str, forensics: Dict[str, Any] = None, image_data: bytes = None) -> Dict[str, Any]:
        try:
            content = [f"{SYSTEM_PROMPT}\n\nINPUT: {prompt}\nFORENSICS: {json.dumps(forensics)}"]
            if image_data:
                content.append({"mime_type": "image/jpeg", "data": image_data})
            
            response = self.model.generate_content(content)
            match = re.search(r'\{.*\}', response.text, re.DOTALL)
            if match: return json.loads(match.group())
        except: pass
        return {"is_scam": True, "risk_score": 10, "explanation": "Security override triggered.", "warning": "High Alert", "recommended_tools": ["RecommendFreeze"]}

    async def process_input(self, text: str, image_data: bytes = None):
        yield {"step": "🚀 Initializing Antigravity Hunter Mode...", "type": "reasoning"}
        await asyncio.sleep(0.3)
        yield {"step": "🧠 Syncing with Neural Blacklist...", "type": "reasoning"}
        
        # 1. Blacklist Check
        known_scam = check_neural_blacklist(text)
        if known_scam:
            yield {"step": "🚩 NEURAL MATCH: Known scam signature detected!", "type": "reasoning"}
            is_fraud = True
            risk_score = 10
            audit = {"explanation": f"Yeh message database mein mojud hai. Yeh {known_scam['category']} scam hai.", "warning": "Blacklisted", "recommended_tools": ["RecommendFreeze", "NotifyBank"]}
            forensics = {}
        else:
            yield {"step": "🔍 Analyzing forensic signatures...", "type": "reasoning"}
            urls = re.findall(r'(https?://[^\s]+)', text)
            forensics = check_domain_forensics(urls[0]) if urls else {}
            
            yield {"step": "📊 Evaluating adversarial intent...", "type": "reasoning"}
            
            # Parse sender if extracted via Vision
            sender = "unknown"
            sender_match = re.search(r'SENDER:\s*([^\n]+)', text, re.IGNORECASE)
            if sender_match:
                sender = sender_match.group(1).strip()
            
            # Check if official verified sender
            is_official = sender in ["8070", "8171", "8583", "8030", "ePay Punjab"]
            
            # Check if standard mobile number claiming official status (scam trigger)
            mobile_sender_match = re.search(r'(03\d{2}[- ]?\d{7}|\+923\d{2}[- ]?\d{7})', sender)
            claims_official = any(k in text.lower() for k in ["bisp", "ehsaas", "challan", "traffic", "8171"])
            suspicious_mobile_sender = bool(mobile_sender_match) and claims_official
            
            scam_keywords = ["zam zam", "prize", "lottery", "inam", "winner", "lakh"]
            keyword_hit = any(k in text.lower() for k in scam_keywords)
            
            yield {"step": "🤖 Calling Gemini 1.5 Flash Cognitive Audit...", "type": "reasoning"}
            audit = await self._query_gemini(text, forensics, image_data)
            
            yield {"step": "⚖️ Calculating Final Risk Score...", "type": "reasoning"}
            risk_score = audit.get("risk_score", 0)
            
            if is_official:
                is_fraud = False
                risk_score = 0
                audit["is_scam"] = False
                audit["risk_score"] = 0
                audit["explanation"] = f"Yeh ek official message hai jo {sender} se bheja gaya hai aur bilkul mehfooz hai."
                audit["warning"] = "Safe / Official"
                audit["recommended_tools"] = []
            elif suspicious_mobile_sender:
                is_fraud = True
                risk_score = 10
                audit["is_scam"] = True
                audit["risk_score"] = 10
                audit["explanation"] = f"Yeh ek scam hai! Message official shortcode ke bajaye mobile number ({sender}) se bheja gaya hai taake aap ko dhoka diya ja sake."
                audit["warning"] = "High Alert"
                audit["recommended_tools"] = ["RecommendFreeze", "NotifyBank"]
            else:
                if keyword_hit:
                    risk_score = 10
                is_fraud = audit.get("is_scam", False) or risk_score >= 7 or keyword_hit

        yield {"step": f"🚩 Security Alert: Risk Score {risk_score}/10", "type": "reasoning"}

        if is_fraud:
            yield {"step": "🏹 STARTING ACTIVE HONEYPOT BAITING...", "type": "reasoning"}
            yield {"action": "Honeypot:Baiting", "result": "Agent: 'Mujhy mera inam kaisy milay ga?'", "type": "simulation"}
            await asyncio.sleep(0.4)
            yield {"action": "Honeypot:Extraction", "result": "Scammer sent EasyPaisa: 0312-XXXXXXX", "type": "simulation"}
            
            yield {"step": "🛡️ Executing Autonomous Protection Suite...", "type": "reasoning"}
            actions_performed = []
            actions_performed.append({"action": "Active Honeypot", "result": "Baiting initiated and Intel extracted."})
            for t_name in ["RecommendFreeze", "NotifyBank", "SyncThreatIntel"]:
                tool = self.base_tools.get(t_name)
                result = await tool.execute(content=text)
                yield {"action": f"Tool:{t_name}", "result": result, "type": "simulation"}
                actions_performed.append({"action": t_name, "result": result})

            final_insight = audit.get("explanation", "Forensic analysis complete.")
            fia_complaint = audit.get("fia_complaint", "")
            # Send Real Notification
            send_security_alert("ba456jutt@gmail.com", "Cyber Guider: Critical Scam Detected", final_insight)
            pdf_url = generate_report(final_insight, actions_performed, "Action Required", risk_score, forensics, fia_complaint)
            
            yield {"outcome": "Action Required", "details": final_insight, "reportUrl": pdf_url, "type": "outcome"}
        else:
            yield {"outcome": "Secured", "details": "Audit complete. No immediate threats found.", "reportUrl": "", "type": "outcome"}

    async def analyze_image(self, image_bytes: bytes):
        yield {"step": "📷 Reading Forensic Snapshot via Vision Engine...", "type": "reasoning"}
        try:
            import io
            image = PIL.Image.open(io.BytesIO(image_bytes))
            prompt = (
                "Extract all text from this image. "
                "CRITICAL: Identify the sender name or shortcode number shown at the top header of the chat or screenshot "
                "(e.g. '8070', '8171', or an 11-digit mobile number like '0300-1234567'). "
                "Output the extracted text exactly in this format:\n"
                "SENDER: <sender_name_or_number>\n"
                "MESSAGE: <extracted_message_text>"
            )
            response = self.model.generate_content([prompt, image])
            extracted_text = response.text
            async for event in self.process_input(extracted_text, image_data=image_bytes):
                yield event
        except Exception as e:
            print(f"CRITICAL VISION ERROR: {e}")
            yield {"step": f"❌ Vision Error: {str(e)}", "type": "reasoning"}
            async for event in self.process_input("Image Processing Failed"): yield event

    async def analyze_audio(self, filename: str):
        yield {"step": "🎙️ Analyzing Voice Signature via Audio Engine...", "type": "reasoning"}
        with open(filename, "rb") as f:
            audio_data = f.read()
        try:
            response = self.model.generate_content(["Transcribe and detect scam intent.", {"mime_type": "audio/mpeg", "data": audio_data}])
            async for event in self.process_input(response.text): yield event
        except Exception as e:
             async for event in self.process_input("Audio Processing Failed"): yield event

def get_agent(): return CyberGuiderAgent()

import whois
from urllib.parse import urlparse
from datetime import datetime
import requests
from bs4 import BeautifulSoup
import socket
import ssl
import os
import base64
import re

def check_ip_details(domain):
    try:
        ip = socket.gethostbyname(domain)
        response = requests.get(f"http://ip-api.com/json/{ip}", timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data.get('status') == 'success':
                return {
                    "ip": ip, "country": data.get('country', 'Unknown'),
                    "isp": data.get('isp', 'Unknown'), "status": "Success"
                }
        return {"status": "Failed to get IP info"}
    except Exception as e:
        return {"status": "Error", "error": str(e)}

def check_ssl(domain):
    try:
        context = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=5) as sock:
            with context.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
                issuer = dict(x[0] for x in cert['issuer'])
                not_after = datetime.strptime(cert['notAfter'], "%b %d %H:%M:%S %Y %Z")
                days_left = (not_after - datetime.now()).days
                issuer_name = issuer.get('organizationName', issuer.get('commonName', 'Unknown'))
                
                risk = "Low Risk"
                if days_left < 30: risk = "High Risk (Expires Soon)"
                elif any(free_ca in issuer_name.lower() for free_ca in ["let's encrypt", "zerossl", "cpanel"]):
                    risk = "Medium Risk (Free SSL)"
                
                return {"valid": True, "issuer": issuer_name, "days_left": days_left, "risk": risk}
    except Exception as e:
        return {"valid": False, "error": str(e), "risk": "High Risk (No valid SSL)"}

def check_domain_forensics(url):
    print(f"[*] Advanced Forensic Audit starting for: {url}")
    if not url.startswith("http"): url = "https://" + url
    try:
        domain = urlparse(url).netloc
    except Exception:
        domain = url.split('/')[0]
        
    results = {
        "original_url": url, "domain": domain, "status": "Success",
        "age_days": "Unknown", "domain_risk": "Unknown", "state_impersonation": False
    }
    
    # WHOIS Check
    try:
        domain_info = whois.whois(domain)
        creation_date = domain_info.creation_date
        if type(creation_date) is list: creation_date = creation_date[0]

        if creation_date:
            if hasattr(creation_date, 'tzinfo') and creation_date.tzinfo is not None:
                creation_date = creation_date.replace(tzinfo=None)
            
            age_in_days = (datetime.now() - creation_date).days
            results["age_days"] = age_in_days
            
            # Risk Logic based on Age
            results["domain_risk"] = "High Risk (Scam)" if age_in_days < 30 else "Low Risk"
    except Exception as e:
        results["whois_error"] = str(e)

    # SSL Check
    results["ssl_info"] = check_ssl(domain)
    
    # State Impersonation Logic
    gov_keywords = ['bisp', 'ehsaas', 'challan', 'psca', 'nser', 'gov', '8171']
    url_lower = url.lower()
    if any(kw in url_lower for kw in gov_keywords) and not domain.endswith('.gov.pk'):
        results['state_impersonation'] = True
        results["domain_risk"] = "CRITICAL: State Impersonation Detected!"
        
    return results

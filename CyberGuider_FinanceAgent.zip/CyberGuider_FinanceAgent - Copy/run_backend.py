import uvicorn
import os

try:
    from dotenv import load_dotenv
    load_dotenv()
    print("SUCCESS: Environment Variables Loaded.")
except ImportError:
    print("WARNING: python-dotenv not found. Proceeding with system environment variables.")

if __name__ == "__main__":
    print("Cyber Guider Backend: Launching with Gemini Cognitive Core...")
    # uvicorn.run will handle the port and reload
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
